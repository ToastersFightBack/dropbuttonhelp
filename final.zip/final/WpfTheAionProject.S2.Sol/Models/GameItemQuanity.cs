﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfTheAionProject.Models
{
    public class GameItemQuanity
    {
        public GameItem GameItem { get; set; }
        public int Quantity { get; set; }
        public GameItemQuanity()
        {

        }

        public GameItemQuanity(GameItem gameItem, int quantity)
        {
            GameItem = gameItem;
            Quantity = quantity;
        }
    }
}

