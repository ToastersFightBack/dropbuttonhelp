﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace WpfTheAionProject.Models
{
    public class Map
    {
        #region ENUMERABLES


        #endregion

        #region FIELDS



        #endregion

        #region PROPERTIES
        private ObservableCollection<Location> _locations;
        private Location _currentLocation;
        private ObservableCollection<Location> _acessableLocations;

        public ObservableCollection<Location> AccesibleLocations
        {
            get {

                _acessableLocations = new ObservableCollection<Location>();

                foreach (var location in _locations)
                {
                    if (location.Accessible == true)
                    {
                        _acessableLocations.Add(location);
                    }
                }
                return _acessableLocations;
            }
            
        }


        public Location CurrentLocation
        {
            get { return _currentLocation; }
            set { _currentLocation = value; }
        }

        public ObservableCollection<Location> Locations
        {
            get { return _locations; }
            set { _locations = value; }
        }




        #endregion

        #region CONSTRUCTORS



        #endregion

        #region METHODS

        public void Move(Location location)
        {
            _currentLocation = location;
        }

        #endregion
    }
}
